
import java.util.Scanner;

/**
 *
 * @author erichuiza
 */
abstract class Registro {
    abstract public void cargar(Scanner archivo);
    abstract public void imprimir();
}
