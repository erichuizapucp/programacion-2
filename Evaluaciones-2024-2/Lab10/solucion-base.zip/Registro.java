import java.util.Scanner;

abstract class Registro {
    abstract public void cargar(Scanner archivo);
    abstract public void imprimir();
}
